-- ==============================================================================
-- 1. TABLAS MAESTRAS
-- ==============================================================================

-- Sedes de WankaFood
CREATE TABLE public.locations (
  id uuid NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  name_es text NOT NULL,
  name_en text,
  address text NOT NULL,
  opening_hours_es jsonb,
  opening_hours_en jsonb,
  latitude numeric,
  longitude numeric,
  created_at timestamp with time zone DEFAULT now(),
  updated_at timestamp with time zone DEFAULT now()
);

-- Categorías de productos
CREATE TABLE public.categories (
  id uuid NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  name_es text NOT NULL UNIQUE,
  name_en text NOT NULL UNIQUE,
  description_es text,
  description_en text,
  created_at timestamp with time zone DEFAULT now(),
  updated_at timestamp with time zone DEFAULT now()
);

-- Perfiles de usuario (Sin email ni password, vinculados a Auth)
CREATE TABLE public.profiles (
  id uuid NOT NULL PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  name text,
  phone_number text,
  -- CORRECCIÓN SQA
  role text NOT NULL DEFAULT 'user'::text CHECK (role IN ('user', 'admin', 'auditor', 'empleado')), 
  created_at timestamp with time zone DEFAULT now(),
  updated_at timestamp with time zone DEFAULT now()
);

-- Catálogo de productos
CREATE TABLE public.products (
  id uuid NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  category_id uuid NOT NULL REFERENCES public.categories(id) ON DELETE RESTRICT,
  name_es text NOT NULL,
  name_en text,
  description_es text,
  description_en text,
  price numeric NOT NULL CHECK (price >= 0),
  stock integer NOT NULL DEFAULT 0 CHECK (stock >= 0),
  image_urls text[], 
  thumbnail_url text,
  created_at timestamp with time zone DEFAULT now(),
  updated_at timestamp with time zone DEFAULT now()
);

-- Pedidos
CREATE TABLE public.orders (
  id uuid NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id uuid NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
  location_id uuid NOT NULL REFERENCES public.locations(id) ON DELETE RESTRICT,
  order_date timestamp with time zone DEFAULT now(),
  pickup_date timestamp with time zone NOT NULL,
  -- CORRECCIÓN SQA: Restricción CHECK agregada para el estado de las órdenes
  status text NOT NULL DEFAULT 'pending'::text CHECK (status IN ('pending', 'processing', 'ready', 'completed', 'cancelled')),
  total_price numeric NOT NULL DEFAULT 0 CHECK (total_price >= 0),
  notes text,
  created_at timestamp with time zone DEFAULT now(),
  updated_at timestamp with time zone DEFAULT now()
);

-- Detalle de pedidos
CREATE TABLE public.order_items (
  order_id uuid NOT NULL REFERENCES public.orders(id) ON DELETE CASCADE,
  product_id uuid NOT NULL REFERENCES public.products(id) ON DELETE RESTRICT,
  quantity integer NOT NULL CHECK (quantity > 0),
  price_at_purchase numeric NOT NULL,
  PRIMARY KEY (order_id, product_id)
);

-- ==============================================================================
-- 2. ÍNDICES PARA OPTIMIZACIÓN (CORRECCIÓN SQA)
-- ==============================================================================
CREATE INDEX idx_products_category_id ON public.products(category_id);
CREATE INDEX idx_orders_user_id ON public.orders(user_id);
CREATE INDEX idx_orders_location_id ON public.orders(location_id);
CREATE INDEX idx_order_items_order_id ON public.order_items(order_id);
CREATE INDEX idx_order_items_product_id ON public.order_items(product_id);

-- ==============================================================================
-- 3. SISTEMA DE AUDITORÍA 
-- ==============================================================================

CREATE TABLE public.auditoria (
  pk_idmovimiento uuid NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  entidad_afectada varchar NOT NULL,
  operacion varchar NOT NULL,
  usuario_id uuid REFERENCES public.profiles(id) ON DELETE SET NULL,
  dato_anterior jsonb,
  dato_nuevo jsonb,
  timestamp timestamptz DEFAULT now(),
  ip_origen varchar,
  user_agent text
);

-- Función de Trigger para Auditoría
CREATE OR REPLACE FUNCTION public.fn_registro_auditoria()
RETURNS trigger AS $$
DECLARE
    v_user_id uuid := auth.uid();
    v_ip_origen varchar := current_setting('request.headers', true)::json->>'x-forwarded-for';
    v_user_agent text := current_setting('request.headers', true)::json->>'user-agent';
BEGIN
    IF TG_OP = 'INSERT' THEN
        INSERT INTO public.auditoria (entidad_afectada, operacion, usuario_id, dato_nuevo, ip_origen, user_agent)
        VALUES (TG_TABLE_NAME, TG_OP, v_user_id, row_to_json(NEW)::jsonb, v_ip_origen, v_user_agent);
        RETURN NEW;
    ELSIF TG_OP = 'UPDATE' THEN
        INSERT INTO public.auditoria (entidad_afectada, operacion, usuario_id, dato_anterior, dato_nuevo, ip_origen, user_agent)
        VALUES (TG_TABLE_NAME, TG_OP, v_user_id, row_to_json(OLD)::jsonb, row_to_json(NEW)::jsonb, v_ip_origen, v_user_agent);
        RETURN NEW;
    ELSIF TG_OP = 'DELETE' THEN
        INSERT INTO public.auditoria (entidad_afectada, operacion, usuario_id, dato_anterior, ip_origen, user_agent)
        VALUES (TG_TABLE_NAME, TG_OP, v_user_id, row_to_json(OLD)::jsonb, v_ip_origen, v_user_agent);
        RETURN OLD;
    END IF;
    RETURN NULL;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Triggers de Auditoría 
CREATE TRIGGER trg_audit_products AFTER INSERT OR UPDATE OR DELETE ON public.products FOR EACH ROW EXECUTE FUNCTION public.fn_registro_auditoria();
CREATE TRIGGER trg_audit_orders AFTER INSERT OR UPDATE OR DELETE ON public.orders FOR EACH ROW EXECUTE FUNCTION public.fn_registro_auditoria();
CREATE TRIGGER trg_audit_profiles AFTER UPDATE OR DELETE ON public.profiles FOR EACH ROW EXECUTE FUNCTION public.fn_registro_auditoria();

-- CORRECCIÓN SQA
CREATE TRIGGER trg_audit_locations AFTER INSERT OR UPDATE OR DELETE ON public.locations FOR EACH ROW EXECUTE FUNCTION public.fn_registro_auditoria();
CREATE TRIGGER trg_audit_categories AFTER INSERT OR UPDATE OR DELETE ON public.categories FOR EACH ROW EXECUTE FUNCTION public.fn_registro_auditoria();
CREATE TRIGGER trg_audit_order_items AFTER INSERT OR UPDATE OR DELETE ON public.order_items FOR EACH ROW EXECUTE FUNCTION public.fn_registro_auditoria();

-- ==============================================================================
-- 4. AUTOMATIZACIÓN DE PERFILES (AUTH -> PUBLIC)
-- ==============================================================================

CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS trigger AS $$
BEGIN
  INSERT INTO public.profiles (id, name, role)
  VALUES (
    new.id, 
    new.raw_user_meta_data->>'name', 
    COALESCE(new.raw_user_meta_data->>'role', 'user')
  );
  RETURN new;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

CREATE TRIGGER on_auth_user_created AFTER INSERT ON auth.users FOR EACH ROW EXECUTE FUNCTION public.handle_new_user();

-- ==============================================================================
-- 5. ROW LEVEL SECURITY (RLS) - POLÍTICAS
-- ==============================================================================

ALTER TABLE public.locations ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.categories ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.products ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.orders ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.order_items ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.auditoria ENABLE ROW LEVEL SECURITY;

-- Políticas de lectura pública
CREATE POLICY "Lectura pública de locations" ON public.locations FOR SELECT USING (true);
CREATE POLICY "Lectura pública de categories" ON public.categories FOR SELECT USING (true);
CREATE POLICY "Lectura pública de products" ON public.products FOR SELECT USING (true);

-- Políticas de Perfil
CREATE POLICY "Usuarios gestionan su perfil" ON public.profiles FOR ALL USING (auth.uid() = id);

-- Políticas de Pedidos (Dueños y Admins)
CREATE POLICY "Usuarios ven sus pedidos" ON public.orders FOR SELECT USING (auth.uid() = user_id OR (SELECT role FROM public.profiles WHERE id = auth.uid()) = 'admin');
CREATE POLICY "Usuarios crean sus pedidos" ON public.orders FOR INSERT WITH CHECK (auth.uid() = user_id);
CREATE POLICY "Lectura items de pedidos propios" ON public.order_items FOR SELECT USING (EXISTS (SELECT 1 FROM public.orders WHERE id = order_id AND user_id = auth.uid()) OR (SELECT role FROM public.profiles WHERE id = auth.uid()) = 'admin');

-- Política de Auditoría (Solo Admin y Auditor)
CREATE POLICY "Acceso restringido auditoria" ON public.auditoria FOR SELECT USING ((SELECT role FROM public.profiles WHERE id = auth.uid()) IN ('admin', 'auditor'));

-- Administración (Acceso total para role='admin')
CREATE POLICY "Admin total locations" ON public.locations FOR ALL USING ((SELECT role FROM public.profiles WHERE id = auth.uid()) = 'admin');
CREATE POLICY "Admin total categories" ON public.categories FOR ALL USING ((SELECT role FROM public.profiles WHERE id = auth.uid()) = 'admin');
CREATE POLICY "Admin total products" ON public.products FOR ALL USING ((SELECT role FROM public.profiles WHERE id = auth.uid()) = 'admin');